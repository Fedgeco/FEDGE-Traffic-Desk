# FEDGE Traffic Desk

A single-page app for running the FEDGE Consult 28-day traffic test: daily log, outreach CRM, content planner, UTM link builder and a weekly scorecard. No build step, no dependencies, no server.

Target site: fedgeco.io. Target markets: UK, US, Netherlands, Norway and wider Europe.

## Features

- **Today:** 28-day strip, 60-minute routine checklist, daily numbers (posts, comments, sessions, target-country sessions, enquiries).
- **Week 0:** the seven foundation fixes to complete before sending traffic.
- **Outreach:** prospect list with status pipeline. Messages sent, replies and calls are counted from this list. Prospects still on "Sent" after five days are flagged as follow-ups due.
- **Content:** planned LinkedIn posts and articles with status tracking.
- **Links:** UTM builder with a saved list.
- **Scorecard:** weekly results against targets, outreach funnel, sessions per week, CSV export.
- **Settings:** start date, daily quota, targets, weekly outreach plan, JSON export, reset.

## Run locally

Open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Deploy on GitHub Pages

1. Create a repository and push this folder to the `main` branch.
2. In the repository, go to **Settings > Pages** and set **Source** to **GitHub Actions**.
3. Push to `main`. The workflow in `.github/workflows/pages.yml` publishes the site.

## Data and privacy

Everything is stored in your browser's `localStorage` under the key `fedge-traffic-desk-v1`. Nothing is sent to a server. Data is per browser and per device, so use **Settings > Export all data (JSON)** to back it up. Clearing site data deletes it.

Prospect names and notes are personal data. Keep to B2B contacts with a clear reason for contacting them and an easy opt-out, and check GDPR and local rules for each country.

## Claude-powered features (optional)

When the app is opened inside Claude as a published artifact, three extra capabilities switch on automatically:

- shared storage (`db`), so data follows you between devices,
- **Draft** buttons for outreach messages and LinkedIn posts, and **Analyse with Claude** on the Scorecard (`sample`),
- a native save dialog for exports (`downloads`).

On GitHub Pages or a local server these are unavailable: the AI buttons stay hidden, storage uses `localStorage`, and exports download as normal files. To add AI drafting on your own hosting, replace the `AI` object in `js/app.js` (a function `AI(prompt, {signal, onText})` that streams text) with a call to your own backend. Never put an API key in client-side code.

## Project structure

```
index.html              page shell
css/styles.css          design tokens (lavender, turquoise, black, white), light and dark themes
js/app.js               state, views, actions
.github/workflows/      GitHub Pages deployment
```

## Assumptions

- Default start date is Monday 19 October 2026 (placeholder). Set the real date in Settings.
- Weekly outreach plan: 50 and 75 messages for weeks 1 and 2 come from the programme. Weeks 3 and 4 are assumed at 75 and are editable.
- Targets (300 to 600 sessions, 40% from target countries, 10 to 15 enquiries, 3 to 5 calls) are goals, not predictions. Reset them after the Week 1 baseline.

## Licence

MIT. Change the copyright holder in `LICENSE` if needed.
