/*
 * FEDGE Traffic Desk
 * Single-page app, no build step, no dependencies.
 * Data: browser localStorage by default. When hosted inside Claude artifacts,
 * the optional claude.use("db" | "sample" | "downloads") capabilities add shared
 * storage and AI drafting; without them the app runs fully offline-first and
 * the "Draft" and "Analyse with Claude" buttons stay hidden.
 */
"use strict";
/* ---------- constants ---------- */
const DEFAULT_START = "2026-10-19";
const STATUSES = ["Sent","Followed up","Replied","Call booked","Call held","Enquiry","Not a fit","No reply"];
const COUNTRIES = ["UK","US","Netherlands","Norway","Other Europe","Other"];
const CHANNELS = ["LinkedIn","Email","Directory","Partner","Other"];
const W0 = [
 ["Meta title and description","Replace the create-react-app default. Name the audience and service. End with a booking call-to-action."],
 ["Make pages crawlable","Add prerendering (react-snap or your host's prerender setting) so Google and link previews can read the pages."],
 ["Social preview","Add Open Graph title, description and a 1200x630 image. Test in LinkedIn Post Inspector."],
 ["One conversion goal","Pick 'Book a call' (Calendly) or a short enquiry form. Every page leads there."],
 ["Tracking","Set up GA4 and Search Console. Add events for button click, form submit and booking. Submit a sitemap."],
 ["Audience landing page","'Remote talent for startups': 3 outcomes, 3 real proof points, a price or 'from' range, and the booking button."],
 ["Trust basics","About page with photo and story, privacy policy, contact email, LinkedIn link."]
];
const ROUTINE = [
 ["LinkedIn: post or comment","10 min"],
 ["Outreach: send today's messages","30 min"],
 ["Replies and follow-ups","10 min"],
 ["Log today's numbers","10 min"]
];
const NUMS = [
 ["posts","LinkedIn posts"],["comments","LinkedIn comments"],
 ["sessions","Sessions (GA4)"],["tsessions","Sessions from target countries"],["enq","Enquiries"]
];
const SOURCES=["linkedin","email","directory","partner","medium","ads"];
const MEDIUMS=["organic","outreach","referral","cpc"];
const CAMPAIGNS=["test1_uk","test1_us","test1_nl","test1_no","test1_eu"];

function seedContent(){
  const L=[
   [1,"LinkedIn post","3 mistakes startups make when hiring their first remote team member"],
   [1,"LinkedIn post","What a vetted-talent process looks like behind the scenes"],
   [1,"LinkedIn post","Why GMT matters more than you think for remote collaboration with Europe"],
   [2,"LinkedIn post","Outreach that gets replies: the 4-line structure I use"],
   [2,"LinkedIn post","A real project story (Mentoring Lab platform launch or EpickSet), real numbers only"],
   [2,"LinkedIn post","Hook 1 reworked with a real example"],
   [2,"Article","How to hire remote talent in Ghana: a guide for UK and EU startups"],
   [3,"LinkedIn post","Best-performing hook from weeks 1 and 2"],
   [3,"LinkedIn post","Second best-performing hook"],
   [3,"LinkedIn post","New hook based on replies received"],
   [4,"LinkedIn post","Best-performing hook"],
   [4,"LinkedIn post","Testimonial or case study (only if collected)"],
   [4,"LinkedIn post","Results summary of the test (real numbers)"],
   [4,"Article","Outsourcing B2B outreach: what to hand over and what to keep"]
  ];
  return L.map((r,i)=>({id:"c"+i,week:r[0],type:r[1],topic:r[2],date:"",status:"Planned",link:""}));
}
function fresh(){
  return {v:1,start:DEFAULT_START,startSet:false,
    t:{sessLo:300,sessHi:600,share:40,enqLo:10,enqHi:15,callLo:3,callHi:5,postsWk:3,quota:15,plan:[50,75,75,75]},
    w0:{},log:{},pros:[],content:seedContent(),utm:[],utmBase:"https://www.fedgeco.io/"};
}

/* ---------- date helpers ---------- */
const D=s=>new Date(s+"T00:00:00");
const iso=d=>d.getFullYear()+"-"+String(d.getMonth()+1).padStart(2,"0")+"-"+String(d.getDate()).padStart(2,"0");
const todayS=()=>iso(new Date());
const addDays=(s,n)=>{const d=D(s);d.setDate(d.getDate()+n);return iso(d)};
const diff=(a,b)=>Math.round((D(a)-D(b))/864e5);
const fmt=(s,o)=>D(s).toLocaleDateString("en-GB",o||{weekday:"short",day:"numeric",month:"short"});
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
const uid=()=>Math.random().toString(36).slice(2,9);

/* ---------- state + persistence ---------- */
let S=fresh(), view="today", selDay=null, filter="All", ub={label:"",source:"linkedin",medium:"organic",campaign:"test1_uk",content:""};
let DB=null, AI=null, DL=null, saveTimer=null, saving=false, dirty=false, saveMsg="Saved on this device";
const LS="fedge-traffic-desk-v1";
function lsGet(){try{const r=localStorage.getItem(LS);return r?JSON.parse(r):null}catch(e){return null}}
function lsSet(){try{localStorage.setItem(LS,JSON.stringify(S))}catch(e){}}
function merge(o){const f=fresh();const m=Object.assign(f,o||{});m.t=Object.assign(f.t,(o&&o.t)||{});return m}
function changed(){
  lsSet(); dirty=true; setSaveMsg("Saving…");
  clearTimeout(saveTimer); saveTimer=setTimeout(flush,900);
}
async function flush(){
  if(!DB){dirty=false;setSaveMsg("Saved on this device");return}
  if(saving){saveTimer=setTimeout(flush,600);return}
  saving=true; dirty=false;
  try{await DB.doc("tracker/state").set({json:JSON.stringify(S),at:Date.now()});setSaveMsg("Saved")}
  catch(e){setSaveMsg("Saved on this device only")}
  saving=false; if(dirty){clearTimeout(saveTimer);saveTimer=setTimeout(flush,300)}
}
function setSaveMsg(m){saveMsg=m;const e=document.getElementById("savemsg");if(e)e.textContent=m}
async function boot(){
  const l=lsGet(); if(l) S=merge(l);
  render();
  try{
    if(window.claude&&claude.use){
      DB=await claude.use("db"); AI=await claude.use("sample"); DL=await claude.use("downloads");
    }
  }catch(e){}
  if(DB){
    try{
      const snap=await DB.doc("tracker/state").get();
      if(snap.exists&&snap.data().json){S=merge(JSON.parse(snap.data().json));lsSet();setSaveMsg("Saved")}
      else if(l){flush()}
    }catch(e){DB=null}
  }
  render();
}

/* ---------- derived data ---------- */
const dayNum=s=>diff(s,S.start)+1;
const dayDate=n=>addDays(S.start,n-1);
const wkOf=n=>Math.ceil(n/7);
const DL_=n=>S.log[n]||{};
function prosOnDay(n){return S.pros.filter(p=>p.date===dayDate(n))}
function weekStats(w){
  const r={posts:0,comments:0,sessions:0,tsessions:0,enq:0,outreach:0,replies:0,calls:0};
  for(let n=(w-1)*7+1;n<=w*7;n++){const l=DL_(n);["posts","comments","sessions","tsessions","enq"].forEach(k=>r[k]+=Number(l[k])||0)}
  S.pros.forEach(p=>{const n=dayNum(p.date);if(wkOf(n)===w&&n>=1&&n<=28){r.outreach++;if(p.replied)r.replies++;if(p.call)r.calls++}});
  return r;
}
function totals(){
  const ws=[1,2,3,4].map(weekStats);
  const t={};Object.keys(ws[0]).forEach(k=>t[k]=ws.reduce((a,w)=>a+w[k],0));
  return {ws,t};
}
function followUpDue(p){return p.status==="Sent"&&todayS()>=addDays(p.date,5)}
function w0Done(){return W0.filter((_,i)=>S.w0[i]&&S.w0[i].done).length}
function dayLogged(n){const l=DL_(n);return NUMS.some(([k])=>Number(l[k])>0)||ROUTINE.some((_,i)=>l["r"+i])||prosOnDay(n).length>0}
const pct=(a,b)=>b?Math.round(a/b*100):0;

/* ---------- ui helpers ---------- */
function toast(m){const t=document.createElement("div");t.className="toast";t.textContent=m;document.body.appendChild(t);setTimeout(()=>t.remove(),1800)}
function copy(txt){
  const done=()=>toast("Copied");
  if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(done,()=>fb())}else fb();
  function fb(){const a=document.createElement("textarea");a.value=txt;a.style.position="fixed";a.style.opacity="0";document.body.appendChild(a);a.select();try{document.execCommand("copy");done()}catch(e){toast("Select and copy manually")}a.remove()}
}
async function saveFile(filename,data){
  if(!DL){
    try{
      const url=URL.createObjectURL(new Blob([data],{type:"text/plain;charset=utf-8"}));
      const a=document.createElement("a");a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();
      setTimeout(()=>URL.revokeObjectURL(url),1000);
    }catch(e){copy(data);toast("Download failed; copied instead")}
    return;
  }
  try{await DL.save({filename,data})}catch(e){if(!e||e.code!=="declined")toast("Could not save the file")}
}
const opts=(arr,v)=>arr.map(a=>`<option${a===v?" selected":""}>${esc(a)}</option>`).join("");

/* ---------- views ---------- */
const NAV=[["today","Today"],["week0","Week 0"],["outreach","Outreach"],["content","Content"],["links","Links"],["score","Scorecard"],["settings","Settings"]];
function renderNav(){
  const due=S.pros.filter(followUpDue).length;
  document.getElementById("nav").innerHTML=
   `<div class="brand"><i></i><div>Traffic Desk<small>FEDGE Consult</small></div></div>`+
   NAV.map(([k,l])=>{
     let p="";
     if(k==="week0")p=`<span class="pill">${w0Done()}/7</span>`;
     if(k==="outreach"&&due)p=`<span class="pill alert">${due} due</span>`;
     return `<button class="nb" data-act="nav" data-v="${k}"${view===k?' aria-current="page"':""}>${l}${p}</button>`}).join("")+
   `<div class="save" id="savemsg">${esc(saveMsg)}</div>`;
}
function render(){
  renderNav();
  const m=document.getElementById("main");
  m.innerHTML=({today:vToday,week0:vWeek0,outreach:vOutreach,content:vContent,links:vLinks,score:vScore,settings:vSettings}[view])();
}

function vToday(){
  const tn=dayNum(todayS());
  if(selDay===null)selDay=clamp(tn,1,28);
  const n=selDay,l=DL_(n),date=dayDate(n);
  let hero;
  if(tn<1){
    hero=`<h1>Programme starts in ${1-tn} day${1-tn===1?"":"s"}</h1><p class="sub">Day 1 is ${fmt(S.start,{weekday:"long",day:"numeric",month:"long"})}${S.startSet?"":" (placeholder start date, change it in Settings)"}. Finish Week 0 first: ${w0Done()} of 7 done.</p>`;
  }else if(tn>28){
    hero=`<h1>28 days complete</h1><p class="sub">Open the Scorecard for the results and decide what to scale.</p>`;
  }else{
    hero=`<h1>Day ${tn} of 28</h1><p class="sub">Week ${wkOf(tn)}. ${fmt(todayS(),{weekday:"long",day:"numeric",month:"long"})}</p>`;
  }
  const strip=Array.from({length:28},(_,i)=>{const d=i+1;
    return `<button class="day${dayLogged(d)?" logged":""}${d===tn?" today":""}${d===n?" sel":""}" data-act="day" data-d="${d}" aria-label="Day ${d}, ${fmt(dayDate(d))}">${d}</button>`}).join("");
  const out=prosOnDay(n).length, q=S.t.quota;
  const routine=ROUTINE.map((r,i)=>`<div class="chk${l["r"+i]?" done":""}"><input type="checkbox" data-chg="routine" data-i="${i}"${l["r"+i]?" checked":""} aria-label="${esc(r[0])}"><div class="t"><b>${esc(r[0])}</b><span>${r[1]}</span></div></div>`).join("");
  const nums=NUMS.map(([k,lab])=>`<label class="f">${lab}<div class="stepper"><button data-act="step" data-k="${k}" data-d="-1" aria-label="Decrease">−</button><input type="number" min="0" inputmode="numeric" data-chg="num" data-k="${k}" value="${Number(l[k])||0}"><button data-act="step" data-k="${k}" data-d="1" aria-label="Increase">+</button></div></label>`).join("");
  return `<div class="head"><div>${hero}</div></div>
  <div class="panel"><div class="strip" role="group" aria-label="28 days">${strip}</div>
    <p class="sub" style="margin-top:10px;font-size:.85rem">Filled turquoise = something logged. Dashed ring = today. Lavender = the day you are editing.</p></div>
  <div class="panel"><div class="row" style="justify-content:space-between"><h2>Day ${n}: ${fmt(date)}</h2><span class="tag">Week ${wkOf(n)}</span></div>
    <div class="grid" style="margin-top:12px">
      <div><h3>Routine (60 min)</h3>${routine}</div>
      <div><h3>Outreach today</h3>
        <p style="margin:8px 0"><b style="font:700 1.8rem var(--display)">${out}</b> <span class="sub">of ${q} messages logged</span></p>
        <div class="bar"><b style="width:${clamp(pct(out,q),0,100)}%"></b></div>
        <div class="row" style="margin-top:12px"><button class="btn pri" data-act="goadd">Log a prospect</button></div>
        <p class="sub" style="margin-top:8px;font-size:.88rem">Outreach, replies and calls count automatically from the Outreach list.</p></div>
    </div></div>
  <div class="panel"><h2>Numbers for day ${n}</h2>
    <div class="grid">${nums}</div>
    <label class="f" style="margin-top:14px">Notes<textarea data-chg="notes" placeholder="What worked, what didn't, who to follow up">${esc(l.notes||"")}</textarea></label>
    <p class="sub" style="margin-top:8px;font-size:.88rem">Take sessions, country split and enquiries from GA4 and your inbox. Leave a field at 0 if you don't have the number yet.</p></div>`;
}

function vWeek0(){
  const d=w0Done(),items=W0.map((w,i)=>{const s=S.w0[i]||{};
    return `<div class="chk${s.done?" done":""}"><input type="checkbox" data-chg="w0" data-i="${i}"${s.done?" checked":""} aria-label="${esc(w[0])}"><div class="t"><b>${esc(w[0])}</b><span>${esc(w[1])}</span></div>${s.done&&s.date?`<span class="tag ok">${fmt(s.date)}</span>`:""}</div>`}).join("");
  return `<div class="head"><div><h1>Week 0: fix the foundations</h1><p class="sub">Finish these before sending any traffic. Prerendering and the meta description decide whether Google and LinkedIn show anything useful.</p></div></div>
  <div class="panel"><div class="row" style="justify-content:space-between"><h2>${d} of 7 done</h2><span class="tag ${d===7?"ok":"warn"}">${d===7?"Ready for traffic":"Not ready yet"}</span></div>
    <div class="bar" style="margin:12px 0 8px"><b style="width:${pct(d,7)}%"></b></div>${items}</div>`;
}

function vOutreach(){
  const P=S.pros,rep=P.filter(p=>p.replied).length,calls=P.filter(p=>p.call).length,due=P.filter(followUpDue).length;
  const list=P.slice().sort((a,b)=>b.date.localeCompare(a.date)).filter(p=>filter==="All"||(filter==="Follow-up due"?followUpDue(p):p.status===filter));
  const rows=list.map(p=>`<tr>
    <td><b>${esc(p.name)}</b><br><span class="sub">${esc(p.role||"")}${p.role&&p.company?", ":""}${esc(p.company||"")}</span></td>
    <td>${esc(p.country)}</td><td>${esc(p.channel)}</td><td>${fmt(p.date)}</td>
    <td><select data-chg="pstatus" data-id="${p.id}" aria-label="Status for ${esc(p.name)}">${opts(STATUSES,p.status)}</select></td>
    <td>${followUpDue(p)?`<span class="tag alert">Due ${fmt(addDays(p.date,5))}</span>`:p.status==="Sent"?`<span class="tag">${fmt(addDays(p.date,5))}</span>`:""}</td>
    <td style="white-space:nowrap">${AI?`<button class="btn sm" data-act="draftpro" data-id="${p.id}">Draft</button> `:""}<button class="btn sm" data-act="editnote" data-id="${p.id}">Note</button> <button class="btn sm danger" data-act="delpro" data-id="${p.id}">Delete</button></td></tr>`).join("");
  return `<div class="head"><div><h1>Outreach</h1><p class="sub">B2B contacts with a clear reason and an easy opt-out. Check GDPR and local rules for each country.</p></div></div>
  <div class="grid" style="margin-bottom:18px">
    <div class="stat"><b>${P.length}</b><span>Prospects logged</span></div>
    <div class="stat"><b>${rep}</b><span>Replied (${pct(rep,P.length)}%)</span></div>
    <div class="stat"><b>${calls}</b><span>Calls booked</span></div>
    <div class="stat"><b${due?' style="color:var(--alert)"':""}>${due}</b><span>Follow-ups due</span></div></div>
  <div class="panel" id="addpanel"><h2>Log a prospect</h2>
    <div class="grid">
      <label class="f">Name<input id="p_name" autocomplete="off"></label>
      <label class="f">Company<input id="p_company" autocomplete="off"></label>
      <label class="f">Role<input id="p_role" placeholder="Founder, Ops lead"></label>
      <label class="f">Country<select id="p_country">${opts(COUNTRIES)}</select></label>
      <label class="f">Channel<select id="p_channel">${opts(CHANNELS)}</select></label>
      <label class="f">Date sent<input id="p_date" type="date" value="${todayS()}"></label>
      <label class="f">Segment<input id="p_seg" placeholder="Seed-stage SaaS"></label>
      <label class="f">Message version<input id="p_ver" placeholder="A"></label></div>
    <label class="f" style="margin-top:12px">Notes<input id="p_notes"></label>
    <div class="row" style="margin-top:14px"><button class="btn pri" data-act="addpro">Add prospect</button></div></div>
  <div class="panel"><div class="row" style="justify-content:space-between;margin-bottom:10px"><h2>Pipeline</h2>
    <select id="flt" data-chg="filter" style="width:auto" aria-label="Filter">${opts(["All","Follow-up due",...STATUSES],filter)}</select></div>
    ${rows?`<div class="tw"><table><thead><tr><th>Prospect</th><th>Country</th><th>Channel</th><th>Sent</th><th>Status</th><th>Follow-up</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>`
     :`<div class="empty">${P.length?"No prospects match this filter.":"No prospects yet. Add your first one above. The target is "+S.t.quota+" messages a day."}</div>`}</div>`;
}

function vContent(){
  const pub=S.content.filter(c=>c.status==="Published").length;
  const rows=S.content.map(c=>`<tr>
    <td>${c.week}</td><td><span class="tag ${c.type==="Article"?"warn":""}">${c.type}</span></td>
    <td style="min-width:240px"><input data-chg="ctopic" data-id="${c.id}" value="${esc(c.topic)}" aria-label="Topic"></td>
    <td><input type="date" data-chg="cdate" data-id="${c.id}" value="${esc(c.date)}" aria-label="Planned date"></td>
    <td><select data-chg="cstatus" data-id="${c.id}" aria-label="Status">${opts(["Planned","Drafted","Published"],c.status)}</select></td>
    <td style="white-space:nowrap">${AI?`<button class="btn sm" data-act="draftc" data-id="${c.id}">Draft</button> `:""}<button class="btn sm danger" data-act="delc" data-id="${c.id}" aria-label="Delete">Delete</button></td></tr>`).join("");
  return `<div class="head"><div><h1>Content</h1><p class="sub">Three LinkedIn posts a week and two articles. Use real clients, numbers and testimonials only.</p></div><span class="tag ok">${pub} of ${S.content.length} published</span></div>
  <div class="panel"><div class="tw"><table><thead><tr><th>Wk</th><th>Type</th><th>Topic</th><th>Planned</th><th>Status</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
    <div class="row" style="margin-top:14px"><button class="btn" data-act="addc">Add a post</button></div></div>`;
}

function utmLink(o){return o.source?(S.utmBase||"")+"?utm_source="+encodeURIComponent(o.source)+"&utm_medium="+encodeURIComponent(o.medium)+"&utm_campaign="+encodeURIComponent(o.campaign)+(o.content?"&utm_content="+encodeURIComponent(o.content):""):""}
function vLinks(){
  const saved=S.utm.map(u=>`<tr><td>${esc(u.label||"")}</td><td class="mono">${esc(utmLink(u))}</td><td style="white-space:nowrap"><button class="btn sm" data-act="copyutm" data-id="${u.id}">Copy</button> <button class="btn sm danger" data-act="delutm" data-id="${u.id}">Delete</button></td></tr>`).join("");
  return `<div class="head"><div><h1>Links</h1><p class="sub">Tag every link you share so GA4 shows which source and country sent each visit.</p></div></div>
  <div class="panel"><h2>Build a link</h2>
    <label class="f">Base URL<input data-chg="utmbase" value="${esc(S.utmBase)}"></label>
    <div class="grid" style="margin-top:12px">
      <label class="f">Label<input data-chg="ub" data-k="label" value="${esc(ub.label)}" placeholder="LinkedIn post, UK"></label>
      <label class="f">Source<select data-chg="ub" data-k="source">${opts(SOURCES,ub.source)}</select></label>
      <label class="f">Medium<select data-chg="ub" data-k="medium">${opts(MEDIUMS,ub.medium)}</select></label>
      <label class="f">Campaign<select data-chg="ub" data-k="campaign">${opts(CAMPAIGNS,ub.campaign)}</select></label>
      <label class="f">Content (optional)<input data-chg="ub" data-k="content" value="${esc(ub.content)}" placeholder="hook1"></label></div>
    <div class="out mono" style="min-height:0">${esc(utmLink(ub))}</div>
    <div class="row"><button class="btn pri" data-act="copyub">Copy link</button><button class="btn" data-act="saveub">Save to list</button></div></div>
  <div class="panel"><h2>Saved links</h2>${saved?`<div class="tw"><table><thead><tr><th>Label</th><th>Link</th><th></th></tr></thead><tbody>${saved}</tbody></table></div>`:`<div class="empty">Nothing saved yet.</div>`}</div>`;
}

function vScore(){
  const {ws,t}=totals(),T=S.t;
  const metrics=[
   ["LinkedIn posts","posts",T.postsWk*4,null],["LinkedIn comments","comments",null,null],["Outreach sent","outreach",null,null],["Replies","replies",null,null],
   ["Calls booked","calls",T.callLo,T.callHi],["Sessions (GA4)","sessions",T.sessLo,T.sessHi],
   ["Sessions from target countries","tsessions",Math.round(T.sessLo*T.share/100),Math.round(T.sessHi*T.share/100)],["Enquiries","enq",T.enqLo,T.enqHi]];
  const rows=metrics.map(([lab,k,lo,hi])=>{
    let st="";
    if(lo!=null){const v=t[k];st=v===0?`<span class="tag">Not started</span>`:v>=lo?`<span class="tag ok">On or above target</span>`:v/lo>=.5?`<span class="tag warn">Behind</span>`:`<span class="tag alert">Well behind</span>`}
    return `<tr><td><b>${lab}</b></td>${ws.map(w=>`<td class="n">${w[k]}</td>`).join("")}<td class="n"><b>${t[k]}</b></td><td class="n">${lo==null?"":(hi!=null&&hi!==lo?lo+" to "+hi:lo)}</td><td>${st}</td></tr>`}).join("");
  const plan=T.plan.map((p,i)=>`<td class="n">${ws[i].outreach} / ${p}</td>`).join("");
  const rate=(a,b)=>b?(a/b*100).toFixed(1)+"%":"–";
  const fmax=Math.max(t.outreach,1);
  const fun=[["Outreach",t.outreach],["Replies",t.replies],["Calls",t.calls],["Enquiries",t.enq]].map(([l,v])=>`<div class="fr"><span>${l}</span><div class="bar lav"><b style="width:${pct(v,fmax)}%"></b></div><b style="text-align:right">${v}</b></div>`).join("");
  const smax=Math.max(1,...ws.map(w=>w.sessions),T.sessLo/4);
  const sb=ws.map((w,i)=>`<div class="fr"><span>Week ${i+1}</span><div class="bar"><b style="width:${pct(w.sessions,smax)}%"></b></div><b style="text-align:right">${w.sessions}</b></div>`).join("");
  return `<div class="head"><div><h1>Scorecard</h1><p class="sub">Calculated from your log and the Outreach list. Targets are goals, not predictions: reset them after the Week 1 baseline.</p></div>
    <div class="row">${AI?`<button class="btn lav" data-act="analyse">Analyse with Claude</button>`:""}<button class="btn" data-act="exportcsv">Export CSV</button></div></div>
  <div class="panel"><div class="tw"><table><thead><tr><th>Metric</th><th class="n">Wk 1</th><th class="n">Wk 2</th><th class="n">Wk 3</th><th class="n">Wk 4</th><th class="n">Total</th><th class="n">Target</th><th>Status</th></tr></thead><tbody>${rows}
    <tr><td><b>Outreach vs plan</b></td>${plan}<td class="n"><b>${t.outreach} / ${T.plan.reduce((a,b)=>a+b,0)}</b></td><td></td><td></td></tr></tbody></table></div></div>
  <div class="grid">
    <div class="panel funnel"><h3>Outreach funnel</h3>${fun}
      <p class="sub" style="font-size:.88rem;margin-top:8px">Reply rate ${rate(t.replies,t.outreach)}. Call rate ${rate(t.calls,t.replies)}.</p></div>
    <div class="panel funnel"><h3>Sessions per week</h3>${sb}
      <p class="sub" style="font-size:.88rem;margin-top:8px">Target-country share ${rate(t.tsessions,t.sessions)} (goal ${T.share}%). Enquiry rate ${rate(t.enq,t.sessions)}.</p></div></div>`;
}

function vSettings(){
  const T=S.t, num=(k,lab)=>`<label class="f">${lab}<input type="number" min="0" data-chg="tset" data-k="${k}" value="${T[k]}"></label>`;
  return `<div class="head"><div><h1>Settings</h1><p class="sub">Dates and targets. Changing the start date re-dates every day, but your logged numbers stay on their day number.</p></div></div>
  <div class="panel"><h2>Programme</h2>
    <div class="grid"><label class="f">Start date (Day 1)<input type="date" data-chg="start" value="${S.start}"></label>
      ${num("quota","Outreach messages per day")}${num("postsWk","LinkedIn posts per week")}</div>
    ${S.startSet?"":`<p class="sub" style="margin-top:10px">The start date is a placeholder (Monday 19 October 2026). Set the real day.</p>`}</div>
  <div class="panel"><h2>Targets</h2>
    <div class="grid">${num("sessLo","Sessions, low")}${num("sessHi","Sessions, high")}${num("share","Target-country share (%)")}${num("enqLo","Enquiries, low")}${num("enqHi","Enquiries, high")}${num("callLo","Calls, low")}${num("callHi","Calls, high")}</div>
    <h3 style="margin:16px 0 8px">Outreach messages per week</h3>
    <div class="grid">${T.plan.map((p,i)=>`<label class="f">Week ${i+1}<input type="number" min="0" data-chg="plan" data-i="${i}" value="${p}"></label>`).join("")}</div>
    <p class="sub" style="margin-top:10px;font-size:.88rem">Weeks 1 and 2 come from the programme (50 and 75). Weeks 3 and 4 are an assumption (75): edit them.</p></div>
  <div class="panel"><h2>Your data</h2><div class="row">
    <button class="btn" data-act="exportjson">Export all data (JSON)</button>
    <button class="btn danger" data-act="reset">Reset everything</button></div></div>`;
}

/* ---------- modal / AI ---------- */
function modal(html){const l=document.getElementById("layer");l.innerHTML=`<div class="modal" data-act="mclose"><div role="dialog" aria-modal="true">${html}</div></div>`}
function closeModal(){document.getElementById("layer").innerHTML=""}
let aiCtl=null;
async function runAI(prompt,outId){
  const out=document.getElementById(outId);
  if(!AI){out.textContent="Claude drafting is not available in this view.";return}
  if(aiCtl)aiCtl.abort(); aiCtl=new AbortController();
  out.textContent="Thinking…";
  try{
    await AI(prompt,{cache:false,signal:aiCtl.signal,onText:({text})=>{out.textContent=text}});
  }catch(e){
    if(e&&e.code==="not_granted")out.textContent="Permission to use Claude was not granted. Allow it in the page permissions and try again.";
    else if(e&&e.code==="rate_limited")out.textContent="Too many requests. Wait a moment and try again.";
    else if(!(e&&e.name==="AbortError"))out.textContent=(e&&e.text)?e.text:"Claude could not respond. Try again.";
  }
}
const BRIEF="Context: FEDGE Consult is a Ghana-based consultancy run by Benedicta Frimpong (project manager). It connects early-stage startups with vetted remote talent and handles B2B outreach. Ghana is on GMT. Website: fedgeco.io. Use British English. Never invent clients, results, numbers or testimonials; where real proof is needed, write [ADD REAL EXAMPLE].";
function draftModal(title,fieldsHtml,buildPrompt){
  modal(`<h2>${esc(title)}</h2>${fieldsHtml}<div class="row" style="margin-top:12px"><button class="btn pri" id="gen">Generate draft</button><button class="btn" data-act="mclose2">Close</button></div><div class="out" id="aiout" aria-live="polite">Press Generate draft.</div><div class="row"><button class="btn" id="cp">Copy</button></div>`);
  document.getElementById("gen").onclick=()=>runAI(buildPrompt(),"aiout");
  document.getElementById("cp").onclick=()=>copy(document.getElementById("aiout").textContent);
}

/* ---------- actions ---------- */
const ACT={
  nav(e){view=e.dataset.v;render();window.scrollTo(0,0)},
  day(e){selDay=+e.dataset.d;render()},
  goadd(){view="outreach";render();const p=document.getElementById("addpanel");if(p){p.scrollIntoView({behavior:"smooth"});const i=document.getElementById("p_name");if(i)i.focus()}},
  step(e){const l=S.log[selDay]=S.log[selDay]||{};const k=e.dataset.k;l[k]=Math.max(0,(Number(l[k])||0)+Number(e.dataset.d));changed();render()},
  addpro(){
    const g=id=>document.getElementById(id).value.trim();
    if(!g("p_name")){toast("Add a name first");document.getElementById("p_name").focus();return}
    S.pros.push({id:uid(),date:g("p_date")||todayS(),name:g("p_name"),company:g("p_company"),role:g("p_role"),country:g("p_country"),channel:g("p_channel"),segment:g("p_seg"),version:g("p_ver"),notes:g("p_notes"),status:"Sent",replied:false,call:false});
    changed();render();toast("Prospect added");const i=document.getElementById("p_name");if(i)i.focus();
  },
  delpro(e){if(confirm("Delete this prospect?")){S.pros=S.pros.filter(p=>p.id!==e.dataset.id);changed();render()}},
  editnote(e){
    const p=S.pros.find(x=>x.id===e.dataset.id);
    modal(`<h2>Note for ${esc(p.name)}</h2><label class="f">Notes<textarea id="nt">${esc(p.notes||"")}</textarea></label><div class="row" style="margin-top:12px"><button class="btn pri" id="ns">Save note</button><button class="btn" data-act="mclose2">Cancel</button></div>`);
    document.getElementById("ns").onclick=()=>{p.notes=document.getElementById("nt").value;changed();closeModal()};
  },
  draftpro(e){
    const p=S.pros.find(x=>x.id===e.dataset.id);
    draftModal("Draft outreach for "+p.name,`<label class="f">One specific thing about their startup (leave blank if you don't have one)<input id="dt" placeholder="e.g. they just opened a London hire"></label>`,
      ()=>`${BRIEF}\n\nWrite a ${p.channel==="Email"?"short email (with a subject line)":"LinkedIn message"} of at most 90 words to ${p.name}, ${p.role||"a founder"} at ${p.company||"their startup"} (${p.country}). Offer a 20-minute call about hiring or lead generation bottlenecks and mention the GMT overlap. Personalisation detail from the sender: ${document.getElementById("dt").value.trim()||"none given, so do not invent one"}. Add one short line making it easy to opt out. Sign off as Benedicta. Output only the message.`);
  },
  addc(){S.content.push({id:uid(),week:wkOf(clamp(dayNum(todayS()),1,28)),type:"LinkedIn post",topic:"New topic",date:"",status:"Planned",link:""});changed();render()},
  delc(e){S.content=S.content.filter(c=>c.id!==e.dataset.id);changed();render()},
  draftc(e){
    const c=S.content.find(x=>x.id===e.dataset.id);
    draftModal("Draft: "+c.topic,`<label class="f">Real example or proof to include (optional)<input id="dt" placeholder="A real project, number or lesson"></label>`,
      ()=>`${BRIEF}\n\nWrite a ${c.type==="Article"?"600-word SEO article outline with an introduction and section drafts":"LinkedIn post of 120 to 180 words"} on this topic: "${c.topic}". Audience: founders and ops leads at seed-stage startups in the UK, US, Netherlands and Norway. Lead with the founder's problem, not with Africa as a pitch. Real example supplied by the sender: ${document.getElementById("dt").value.trim()||"none, so use [ADD REAL EXAMPLE] where one is needed"}. End with a soft invitation to book a 20-minute call. Output only the content.`);
  },
  copyub(){copy(utmLink(ub))},
  saveub(){S.utm.push(Object.assign({id:uid()},ub));changed();render();toast("Link saved")},
  copyutm(e){const u=S.utm.find(x=>x.id===e.dataset.id);copy(utmLink(u))},
  delutm(e){S.utm=S.utm.filter(u=>u.id!==e.dataset.id);changed();render()},
  analyse(){
    const {ws,t}=totals();
    const data={day:clamp(dayNum(todayS()),0,28),weeks:ws,totals:t,targets:S.t,week0Done:w0Done(),prospects:S.pros.length,followUpsDue:S.pros.filter(followUpDue).length,
      bySegment:Object.entries(S.pros.reduce((a,p)=>{const k=p.segment||"unspecified";a[k]=a[k]||{sent:0,replied:0};a[k].sent++;if(p.replied)a[k].replied++;return a},{})),
      byChannel:Object.entries(S.pros.reduce((a,p)=>{a[p.channel]=a[p.channel]||{sent:0,replied:0};a[p.channel].sent++;if(p.replied)a[p.channel].replied++;return a},{}))};
    modal(`<h2>Weekly analysis</h2><div class="out" id="aiout" aria-live="polite"></div><div class="row"><button class="btn" id="cp">Copy</button><button class="btn" data-act="mclose2">Close</button></div>`);
    document.getElementById("cp").onclick=()=>copy(document.getElementById("aiout").textContent);
    runAI(`${BRIEF}\n\nYou are analysing a 28-day traffic test for FEDGE. Data (JSON): ${JSON.stringify(data)}\n\nRespond in plain text, no markdown tables, under 220 words: (1) what is working, (2) what to cut, (3) one focus for next week, (4) one experiment to run. Say clearly when numbers are too small to conclude anything. Targets are goals, not predictions. Do not invent data that is not in the JSON.`,"aiout");
  },
  exportcsv(){
    const {ws,t}=totals();
    const keys=["posts","comments","outreach","replies","calls","sessions","tsessions","enq"];
    let c="Metric,Week 1,Week 2,Week 3,Week 4,Total\n"+keys.map(k=>[k,...ws.map(w=>w[k]),t[k]].join(",")).join("\n");
    c+="\n\nDate sent,Name,Company,Role,Country,Channel,Segment,Version,Status,Replied,Call,Notes\n"+S.pros.map(p=>[p.date,p.name,p.company,p.role,p.country,p.channel,p.segment,p.version,p.status,p.replied?"Yes":"No",p.call?"Yes":"No",p.notes].map(v=>'"'+String(v||"").replace(/"/g,'""')+'"').join(",")).join("\n");
    saveFile("fedge-traffic-test.csv",c);
  },
  exportjson(){saveFile("fedge-traffic-desk-data.json",JSON.stringify(S,null,2))},
  reset(){if(confirm("Reset all data in this tracker? This cannot be undone.")){S=fresh();selDay=null;changed();render()}},
  mclose(e,ev){if(ev.target===e)closeModal()},
  mclose2(){closeModal()}
};
const CHG={
  routine(e){const l=S.log[selDay]=S.log[selDay]||{};l["r"+e.dataset.i]=e.checked;changed();render()},
  num(e){const l=S.log[selDay]=S.log[selDay]||{};l[e.dataset.k]=Math.max(0,Math.floor(Number(e.value))||0);changed();render()},
  notes(e){const l=S.log[selDay]=S.log[selDay]||{};l.notes=e.value;changed()},
  w0(e){S.w0[e.dataset.i]={done:e.checked,date:e.checked?todayS():""};changed();render()},
  pstatus(e){const p=S.pros.find(x=>x.id===e.dataset.id);p.status=e.value;
    if(["Replied","Call booked","Call held","Enquiry"].includes(e.value))p.replied=true;
    if(["Call booked","Call held"].includes(e.value))p.call=true;
    changed();render()},
  filter(e){filter=e.value;render()},
  ctopic(e){S.content.find(c=>c.id===e.dataset.id).topic=e.value;changed()},
  cdate(e){S.content.find(c=>c.id===e.dataset.id).date=e.value;changed()},
  cstatus(e){S.content.find(c=>c.id===e.dataset.id).status=e.value;changed();render()},
  utmbase(e){S.utmBase=e.value.trim();changed();render()},
  ub(e){ub[e.dataset.k]=e.value;render()},
  start(e){if(e.value){S.start=e.value;S.startSet=true;selDay=null;changed();render()}},
  tset(e){S.t[e.dataset.k]=Math.max(0,Number(e.value)||0);changed()},
  plan(e){S.t.plan[+e.dataset.i]=Math.max(0,Number(e.value)||0);changed()}
};
document.addEventListener("click",ev=>{
  const el=ev.target.closest("[data-act]");if(!el)return;
  const f=ACT[el.dataset.act];if(f)f(el,ev);
});
document.addEventListener("change",ev=>{
  const el=ev.target.closest("[data-chg]");if(!el)return;
  const f=CHG[el.dataset.chg];if(f)f(el);
});
document.addEventListener("keydown",ev=>{if(ev.key==="Escape")closeModal()});
boot();
